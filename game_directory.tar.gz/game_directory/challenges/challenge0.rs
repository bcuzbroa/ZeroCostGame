/* ======================================================
CHALLENGE 0: SANITY CHECK
=========================================================
*/

/* 1. The "hello" function
@args:    None
@returns: String (owned)

Task: 
Return the exact string "Hello world !".

Note: 
In Rust, there is a difference between a string literal ("...") 
and an owned String. Make sure you return an owned String.
*/

// TODO: Write the hello function here


//Main exemple to test your challenges

fn main() {
    //println!("{}", hello())
}
