/* ======================================================
CHALLENGE: OWNERSHIP & STRING CONCATENATION
=========================================================
*/

/* 1. The "concat" function
@args:    input: String (owned)
@returns: String (owned)

Task: 
Take the input string, append the suffix " processed" to it, 
and return the result.

Example: 
assert_eq!(concat(String::from("foo")), "foo processed")

Questions to consider:
1. Does the function "consume" the input string? 
2. Can you use the '+' operator? If so, does it work like this: 
   `string + &str` or `&str + string`?
3. Is the '+' operator symmetric in Rust?
*/

// TODO: Write the concat function here

fn main() {
   //Implement your tests here
}